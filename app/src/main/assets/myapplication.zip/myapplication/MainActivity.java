package com.example.myapplication;

import android.arch.persistence.room.Room;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.example.myapplication.db.AppDatabase;
import com.example.myapplication.db.Department;
import com.example.myapplication.db.Employee;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "database_name").build();

        new Thread(new Runnable() {
            @Override
            public void run() {
//                for(int i = 1; i <= 5; ++i){
//                    db.departmentEmployeeDao().insertDepartment(new DepartmentEntity("Department " + i, "DEP" + i));
//                }
//
//                for(int i = 1; i < 10; i++){
//                    db.departmentEmployeeDao().insertEmployee(new EmployeeEntity("Name " + i, "1234"));
//                    db.departmentEmployeeDao().assignEmployeeDepartment(new DepartEmpEntity(i, 1 + i % 5, "NV"));
//                }

                List<Department> employeeList = db.departmentEmployeeDao().getAllDepartment();
                for(Department d : employeeList){
                    Log.d("VuLV", d.mDepartment.mName + " - " + d.mListEmployees.size());
                }
            }
        }).start();
    }
}

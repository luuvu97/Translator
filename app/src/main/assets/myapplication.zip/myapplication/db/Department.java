package com.example.myapplication.db;

import android.arch.persistence.room.Embedded;
import android.arch.persistence.room.Relation;

import java.util.List;

public class Department {
    @Embedded
    public DepartmentEntity mDepartment;

    @Relation(
            parentColumn = "department_id",
            entity = DepartEmpEntity.class,
            entityColumn = "department_id",
            projection = "employee_id"
    )
    public List<EmployeeEntity> mListEmployees;


}

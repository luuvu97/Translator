package com.example.myapplication.db;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Index;
import android.arch.persistence.room.PrimaryKey;

@Entity(indices = @Index("department_id"))
public class DepartmentEntity {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "department_id")
    public int mId;

    @ColumnInfo(name = "name")
    public String mName;

    @ColumnInfo(name = "short_name")
    public String mShortName;

    public DepartmentEntity(String mName, String mShortName) {
        this.mName = mName;
        this.mShortName = mShortName;
    }
}

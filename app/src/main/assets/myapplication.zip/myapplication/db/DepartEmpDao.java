package com.example.myapplication.db;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;

@Dao
public interface DepartEmpDao {
    @Query("SELECT * FROM EmployeeEntity")
    public List<Employee> getAllEmployee();

    @Query("SELECT * FROM EmployeeEntity JOIN DepartEmpEntity JOIN DepartmentEntity" +
            " ON EmployeeEntity.employee_id = DepartEmpEntity.employee_id AND DepartEmpEntity.department_id = DepartmentEntity.department_id" +
            " WHERE fullname LIKE :name")
    public List<Employee> findEmployee(String name);

    @Query("SELECT * FROM EmployeeEntity WHERE employee_id LIKE :employeeCode COLLATE NOCASE")
    public List<EmployeeEntity> findEmployeeByCode(String employeeCode);

    @Query("SELECT * FROM DepartmentEntity")
    public List<Department> getAllDepartment();

    @Query("SELECT * FROM DepartmentEntity WHERE DepartmentEntity.name LIKE :searchText OR DepartmentEntity.name LIKE :searchText COLLATE NOCASE")
    public List<Department> findDepartment(String searchText);

    @Query("UPDATE DepartEmpEntity SET department_id = :departmentId and position = :position WHERE employee_id = :employeeId")
    public void updateEmployeeDepartment(long employeeId, long departmentId, String position);

    @Insert
    public long insertEmployee(EmployeeEntity employee);

    @Insert
    public long insertDepartment(DepartmentEntity department);

    @Insert
    public long assignEmployeeDepartment(DepartEmpEntity info);
}

package com.example.myapplication.db;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;

@Database(entities = {EmployeeEntity.class, DepartEmpEntity.class, DepartmentEntity.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract DepartEmpDao departmentEmployeeDao();
}

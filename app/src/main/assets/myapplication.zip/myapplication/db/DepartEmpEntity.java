package com.example.myapplication.db;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.PrimaryKey;

@Entity(foreignKeys = {
        @ForeignKey(entity = DepartmentEntity.class, parentColumns = "department_id", childColumns = "department_id"),
        @ForeignKey(entity = EmployeeEntity.class, parentColumns = "employee_id", childColumns = "employee_id")
})
public class DepartEmpEntity {
    @PrimaryKey
    @ColumnInfo(name = "employee_id")
    public int mEmployeeId;

    @ColumnInfo(name = "department_id")
    public int mDepartmentId;

    @ColumnInfo(name = "position")
    public String mPosition;

    public DepartEmpEntity(int mEmployeeId, int mDepartmentId, String mPosition) {
        this.mEmployeeId = mEmployeeId;
        this.mDepartmentId = mDepartmentId;
        this.mPosition = mPosition;
    }
}

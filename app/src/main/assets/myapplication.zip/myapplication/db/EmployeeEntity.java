package com.example.myapplication.db;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Index;
import android.arch.persistence.room.PrimaryKey;

@Entity(indices = @Index("employee_id"))
public class EmployeeEntity {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "employee_id")
    public int mId;

    @ColumnInfo(name = "fullname")
    public String mFullName;

    @ColumnInfo(name = "contact")
    public String mContact;

    public EmployeeEntity(String mFullName, String mContact) {
        this.mFullName = mFullName;
        this.mContact = mContact;
    }
}

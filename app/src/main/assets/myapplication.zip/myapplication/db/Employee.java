package com.example.myapplication.db;

import android.arch.persistence.room.Embedded;
import android.arch.persistence.room.Relation;

import java.util.List;

public class Employee {
    @Embedded
    EmployeeEntity mEmployee;
    @Relation(
            parentColumn = "employee_id",
            entity = DepartEmpEntity.class,
            entityColumn = "employee_id",
            projection = "department_id"
    )
    List<DepartmentEntity> mListDepartments;
}
